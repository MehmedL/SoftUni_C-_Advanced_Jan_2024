﻿using System;
using System.Globalization;
using StartUp;

namespace StartUp
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Questin6();

            string[] name = Console.ReadLine()
                .Split(' ',StringSplitOptions.RemoveEmptyEntries);
            CustomTuple<string, string> names = 
                new CustomTuple<string, string>($"{name[0]} {name[1]}", name[2]);

            string[] bearTokens = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries);
            CustomTuple<string, int> bears = 
                new CustomTuple<string, int>(bearTokens[0] , int.Parse(bearTokens[1]));

            string[] number = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries);
            CustomTuple<int, double> numbers = 
                new CustomTuple<int, double>(int.Parse(number[0]), double.Parse(number[1],CultureInfo.InvariantCulture));

            Console.WriteLine(names);
            Console.WriteLine(bears);
            Console.WriteLine(numbers);

            }

        private static void Questin6()
        {
            int lines = int.Parse(Console.ReadLine());
            Box<string> myBox = new Box<string>();
            for (int i = 0; i < lines; i++)
            {
                myBox.Add(Console.ReadLine());

            }
            string compareWith = Console.ReadLine();

            Console.WriteLine(myBox.Count(compareWith));
        }
    }
}
