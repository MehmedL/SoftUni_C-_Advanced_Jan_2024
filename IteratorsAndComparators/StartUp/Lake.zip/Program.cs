﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace StartUp
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Listy();

            List<int> list = Console.ReadLine()
                .Split(", ",StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToList();

            Lake lake = new Lake(list);

            string output = string.Join(", ", lake);

            Console.WriteLine(output);


        }

        private static void Listy()
        {
            var input = Console.ReadLine()
                            .Split(' ', StringSplitOptions.RemoveEmptyEntries);

            ListyIterator<string> listyIterator = new ListyIterator<string>(input.Skip(1).ToList());
            string comand;
            while ((comand = Console.ReadLine()).ToLower() != "end")
            {
                switch (comand.ToLower())
                {
                    case "print":
                        try
                        {
                            listyIterator.Print();
                        }
                        catch (InvalidOperationException ioe)
                        {
                            Console.WriteLine("Invalid Operation! ");
                        }

                        break;
                    case "hasnext":
                        Console.WriteLine(listyIterator.HasNext());
                        break;
                    case "move":
                        Console.WriteLine(listyIterator.Move());
                        break;
                    case "printall":
                        foreach (var item in listyIterator)
                        {
                            Console.Write($"{item} ");
                        }
                        Console.WriteLine();
                        break;
                }
            }
        }
    }
}
