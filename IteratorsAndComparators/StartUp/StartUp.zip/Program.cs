﻿using System;
using System.Linq;

namespace StartUp
{
    public class Program
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine()
                .Split(' ',StringSplitOptions.RemoveEmptyEntries);

            ListyIterator<string> listyIterator = new ListyIterator<string> (input.Skip(1).ToList());
            string comand ;
            while((comand = Console.ReadLine()).ToLower() != "end")
            {
                switch (comand.ToLower())
                {
                    case "print":
                        try
                        {
                            listyIterator.Print();
                        }
                        catch(InvalidOperationException ioe)
                        {
                            Console.WriteLine("Invalid Operation! ");
                        }
                        
                        break;
                    case "hasnext":
                        Console.WriteLine(listyIterator.HasNext());
                        break;
                    case "move":
                        Console.WriteLine(listyIterator.Move());
                        break;
                }
            }
        }
    }
}
